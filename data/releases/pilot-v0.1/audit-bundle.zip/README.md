# The AI Canon audit bundle: pilot-v0.1

Self-contained and offline. Rebuild this release and verify it is bit-identical:

    bash reproduce.sh

Contents: the pipeline code (src/canon), the weights (scenarios.yaml), the pinned data
snapshot (data/seeds + data/resolved), and the release outputs (data/releases). No network,
no external repo, no time dependence. A MISMATCH means the release is defective.
